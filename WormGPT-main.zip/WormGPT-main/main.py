from keep_alive import keep_alive
import telegram_bot

if __name__ == "__main__":
    keep_alive()

    telegram_bot.run_bot()
