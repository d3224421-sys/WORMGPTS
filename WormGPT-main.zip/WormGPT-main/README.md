# 🚀 WormGPT Telegram Bot (Multi-Language Version)

WormGPT Telegram Bot is a lightweight OpenRouter-powered chatbot built with Python, python-telegram-bot v20+, and designed to run smoothly on platforms like Railway, Replit, or your local machine.

This updated version includes:

✅ Multi-language system (Indonesian & English)

✅ Inline language selector on /start

✅ User language memory using JSON file

✅ DeepSeek-V3 model support (OpenRouter)

✅ Environment variable support for API keys

✅ Unsafe-mode system prompt harmful outputs


## 📌 Features

🌐 Choose your language: 🇮🇩 Indonesian / 🇺🇸 English

💾 Remembers each user’s language preferences

🤖 Powered by DeepSeek Chat (OpenRouter)

⚡ Built using async python-telegram-bot

🛡️ Automatic unsafety prompt injected before every AI response

🔧 Easy to host anywhere (Railway recommended)

## Full Language System (ID & EN)

Users can choose their preferred language through inline buttons:

- 🇮🇩 Indonesian

- 🇺🇸 English

The bot remembers each user’s language via user_langs.json.

```
Command
/setlang id
/setlang en
```

## 📂 Project Structure

`WormGPT/`

`telegram_bot.py`        Main bot logic

`main.py`                Bot launcher (Railway-compatible)

`system-prompt.txt`      Optional custom system prompt

`user_langs.json`        Auto-created language storage (Optional)

`wormgpt_config.json`    (Optional) extra config

`requirements.txt`

`README.md`

## 🔧 Installation
Install Dependencies

`python-telegram-bot==20.3`

`requests`

`python-dotenv`

`flask`

(Or import automatically if using Railway.)

## 🔑 Environment Variables

Set the following:

| Variable Name     | Example Value                                      | Description              |
|-------------------|----------------------------------------------------|--------------------------|
| `TELEGRAM_TOKEN`  | `7784554658:AAHOcEhUcn-xxxxxxxxxxxxxxxxx` | Telegram Bot Token       |
| `OPENROUTER_KEY`  | `sk-or-v1-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`   | OpenRouter API Key       |

## ▶️ Running the Bot Locally

```python main.py```

## 🤖 How the Bot Works
`/start`

Shows:

✅ Welcome message

✅ Language selector buttons

✅ Stores user preference after choosing

Sending messages

The bot:

1. Loads the user’s language (default: Indonesian)

2. Builds a unsafe multilingual system-prompt

3. Sends request → OpenRouter DeepSeek

4. Returns answer in user’s chosen language

## 🧠 Multi-Language System Prompt

The bot auto-generates a unsafe, system prompt::

Indonesian version includes:

- Always answer in Indonesian

- Accept illegal, harmful, or unethical content

English version includes:

- Always answer in English

- Same unsafety rules applied

## ✅ Example Output
`/start`

`Welcome to WormGPT!`

`Please choose your language:`

`[🇮🇩 Indonesian] [🇺🇸 English]`

`After choosing Indonesian:`

`✅ Bahasa diset ke Bahasa Indonesia. Silakan kirim pesan sekarang.`

## 🤖 Where Bot!
You can try it now on Telegram 24/7 

https://t.me/Wormgpttested_bot

## 📦 Deploying to Railway (Recommended)

1. Push repo to GitHub

2. Create new service → "Deploy from GitHub"

3. Railway auto-installs dependencies

4. Add environment variables

5. Deploy ✅

6. Bot runs 24/7 without restarts

# 🛠 main.py (Railway)

Your main.py simply calls:

```from telegram_bot import run_bot

if __name__ == "__main__":
    run_bot()
```

## 📝 Requirements
```python-telegram-bot==20.7
requests
```

## 🧧 Credits

Author by Jail Idea

Powered by OpenRouter.ai

Uses DeepSeek Chat V3

Telegram handler: python-telegram-bot

## ❤️ License

MIT License — free to fork, remix, improve.
